When unpacking the zip we expect a file structure of:
../
    docker-compose.yml
    Client/..
    Server/..

If you are on windows, you can use the image.bat files in the client/scripts and server/scripts to build the images for the client and server

If not on windows run the commands from the parent directory where the folders Client and Server are located:

docker build ./Client/. -t ads-client
docker build ./Server/. -t ads-server

Then we can run 
docker compose up
to run our phase 1