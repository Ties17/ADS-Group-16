import rpyc

rpyc.connect("localhost", port=18861)